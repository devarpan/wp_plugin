(function($) {
	"use strict"; 
	
	$(document).ready(function() {	
		if ($(".ossvn-process-block").length) process_bar();
	});
	function process_bar(){
		var max_process = 0;
		var current_process = 0;
		var percent_process = 0;

		if($('#ship-to-different-address input').is(':checked')){
			$(".validate-required input").each(function(){
				max_process++;
				if ($(".validate-required input").val() != ""){
					current_process++;
				}
			});
		}else{

			$(".woocommerce-billing-fields .validate-required input").each(function(){
				max_process++;
				if ($(".validate-required input").val() != ""){
					current_process++;
				}
			});
		}

		if (max_process > 0){
			percent_process = Math.floor(current_process * 100 / max_process);
		}
		$(".ossvn-process-block .ossvn-process-bar").width(percent_process + "%");
		$(".ossvn-process-block .ossvn-process-bar span").text(percent_process + "%");
		
		if($('#ship-to-different-address input').is(':checked')){
			
			$(".validate-required input").change(function(){

				var current_status = wct_check_all_fields_process($(".validate-required input"));
				if(current_status != ''){
					if ($(this).val() == ""){
						current_process--;
						if (max_process > 0){
							percent_process = Math.floor(current_process * 100 / max_process);
						}
						$(".ossvn-process-block .ossvn-process-bar").width(percent_process + "%");
						$(".ossvn-process-block .ossvn-process-bar span").text(percent_process + "%");
					}else{
						current_process++;
						if (max_process > 0){
							percent_process = Math.floor(current_process * 100 / max_process);
						}
						$(".ossvn-process-block .ossvn-process-bar").width(percent_process + "%");
						$(".ossvn-process-block .ossvn-process-bar span").text(percent_process + "%");
					}
				}else{
					$(".ossvn-process-block .ossvn-process-bar").width("100%");
					$(".ossvn-process-block .ossvn-process-bar span").text("100%");
				}
				
			});


		}else{
			$(".woocommerce-billing-fields .validate-required .input-text").change(function(){

				
				var current_status = wct_check_all_fields_process($(".woocommerce-billing-fields .validate-required .input-text"));
				if(current_status != ''){
					if ($(this).val() == ""){
						current_process--;
						if (max_process > 0){
							percent_process = Math.floor(current_process * 100 / max_process);
						}
						$(".ossvn-process-block .ossvn-process-bar").width(percent_process + "%");
						$(".ossvn-process-block .ossvn-process-bar span").text(percent_process + "%");
					}else{
						current_process++;
						if (max_process > 0){
							percent_process = Math.floor(current_process * 100 / max_process);
						}
						$(".ossvn-process-block .ossvn-process-bar").width(percent_process + "%");
						$(".ossvn-process-block .ossvn-process-bar span").text(percent_process + "%");
					}
				}else{
					
					$(".ossvn-process-block .ossvn-process-bar").width("100%");
					$(".ossvn-process-block .ossvn-process-bar span").text("100%");
				}
				

			});

		}
	}

	function wct_check_all_fields_process(selector){
		
		var selector = selector;
		var status = '';
		selector.each(function(){
			if ($(this).val() == ""){
				status = '0';
				return;
			}
		});

		return status;
	}

})(jQuery);