<?php 
/**
 * HTML conditional logic
 *
 * @link       http://demo.comfythemes.com/wct/
 * @since      1.0
 *
 * @package    woocommerce-checkout-templates
 * @subpackage woocommerce-checkout-templates/classes/admin/edit-modal
 * @author     OSVN <contact@outsourcevietnam.co>
 * @coder Nam
 */
defined( 'ABSPATH' ) OR exit;
?>
<div id="block-cond-logic" class="ossvn-form-group ossvn-form-group-logic">
	<label class="ossvn-label ossvn-label-user-role" for="ossvn-checkbox-class"><?php _e('Enable conditional logic?', 'wct');?></label>
	<span class="wct_loading"></span>
	<input type="checkbox" name="block-cond-logic"  data-target="block_cond_logic" class="ossvn-get-data ossvn-checkbox-user-role" />
	<div class="conditional ossvn-conditional-logic hidden" data-cond-option="block-cond-logic" data-cond-value="on">
		<select data-target="block_cond_logic_show" class="ossvn-get-data">
			<option value=""><?php _e('Show', 'wct');?></option>
			<option value="hidden"><?php _e('Hidden', 'wct');?></option>
		</select> <?php _e('this field if', 'wct');?>
		<select data-target="block_cond_logic_all" class="ossvn-get-data">
			<option value=""><?php _e('All', 'wct');?></option>
			<option value="any"><?php _e('Any', 'wct');?></option>
		</select> <?php _e('of the following match.', 'wct');?><br><br>
		<div id="ossvn-form-group-logic-rule"></div>
		<a href="" class="submit-block-cond-logic"><?php _e('Add rule', 'wct');?></a>
	</div>
</div>