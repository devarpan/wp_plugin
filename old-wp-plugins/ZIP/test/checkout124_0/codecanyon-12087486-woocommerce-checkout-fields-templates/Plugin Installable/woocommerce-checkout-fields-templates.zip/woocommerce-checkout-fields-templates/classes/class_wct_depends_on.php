<?php 
/**
 * Logic fields
 *
 * @link       http://demo.comfythemes.com/wct/
 * @since      1.0
 *
 * @package    woocommerce-checkout-templates
 * @subpackage woocommerce-checkout-templates/classes
 * @author     wct <contact@outsourcevietnam.co>
 * @coder Nam
 */
defined( 'ABSPATH' ) OR exit;

/**
* 
*/
class WCT_Depends_On
{
	
	function __construct()
	{
		add_action( 'wp_footer', array($this, 'wct_add_block_logic_rule') );
	}

	/**
	* Printf block conditional logic rule
	* @return json
	* @since 1.0
	*/
	public function wct_add_block_logic_rule(){
		
		$out = '';

		if($wct_logic_fields = get_option('_wct_logic_fields')){
			
			if(!empty($wct_logic_fields)):
			
				$out .= '<script type=\'text/javascript\'>';
					
					$out .= '(function($) { \'use strict\';';
					
						foreach ($wct_logic_fields as $key => $values) {
								
							if($values['status'] == 'on'):

								$out .= $this->wct_depends_on_display( $values['all_any'], $key, $values['fields'], $values['show_hide'] );
							
							endif;//end check status is on

						}//endforeach

					$out .= ' } )(jQuery);';

				$out .= '</script>';

			endif;
			
		}

		echo $out;
	}

	/**
	* Display logic field with all or any field
	* Param 1: $type - all/any
	* Param 2: $key - block id
	* Param 3: $value - array() - list all rule
	* Param 4: $all_any - all/any
	* @return js
	* @since 1.0
	*/
	private function wct_depends_on_display( $type = null, $key, $values = array(), $all_any ){

		$out = '';

		$out .= 'if($(\'#'.esc_attr($key).'_field\').length){ ';

			if( isset($type) && $type == 'any' ){

				$out .= '$(\'#'.esc_attr($key).'_field\').dependsOn({';
					
					$i = 0;

					foreach($values as $val){ 

						$value = $val['logic_field_is_value'];

						if($i == 0){

							if( $this->wct_check_prefix_in_block_id( $val['logic_field'] ) ){
								$out .= '\'#'.esc_attr($val['logic_field']).'_field .ossvn-block-field\': {';
							}else{
								$out .= '\'#'.esc_attr($val['logic_field']).'\': {';
							}

								$out .= $this->wct_depends_on_qualifiers( $val['logic_field_is'], $value );

							$out .= '},';
						}

						$i++;
					}

				$out .= '}';

				if($all_any == 'hide'){
					$out .= ',{toggleClass: \'wct-disabled\', hide: false}';
				}	

				if( count($values) > 1 ){

					$out .= ')';
						
						$ii = 0;

						foreach($values as $val){ 

							if($ii != 0){
								
								if( $this->wct_check_prefix_in_block_id( $val['logic_field'] ) ){
									$out .= '\'#'.esc_attr($val['logic_field']).'_field .ossvn-block-field\': {';
								}else{
									$out .= '\'#'.esc_attr($val['logic_field']).'\': {';
								}

									$out .= $this->wct_depends_on_qualifiers( $val['logic_field_is'], $value );

								$out .= '}})';
							}
							$ii++;

						}

					$out .= ';';

				}else{

					$out .= ');';
				}

			}else{

				$out .= '$(\'#'.esc_attr($key).'_field\').dependsOn({';
					
					foreach($values as $val){ 

						$value = $val['logic_field_is_value'];

						if( $this->wct_check_prefix_in_block_id( $val['logic_field'] ) ){
							$out .= '\'#'.esc_attr($val['logic_field']).'_field .ossvn-block-field\': {';
						}else{
							$out .= '\'#'.esc_attr($val['logic_field']).'\': {';
						}

							$out .= $this->wct_depends_on_qualifiers( $val['logic_field_is'], $value );

						$out .= '},';
					}

				$out .= '}';

				if($all_any == 'hide'){
					$out .= ',{toggleClass: \'wct-disabled\', hide: false}';
				}

				$out .= ');';
			}

		$out .= ' }';

		return $out;

	}

	/**
	* Qualifiers dependsOn()
	* Param 1: $type - type dependsOn
	* Param 2: $value - value logic field
	* @return value
	* @since 1.0
	*/
	private function wct_depends_on_qualifiers($type, $value){

		$out = '';

		switch ( $type ) {

			case 'isnot':
				$out .= 'not: [\''.esc_attr($value).'\']';
				break;
			case 'contains':
				$out .= 'contains: [\''.esc_attr($value).'\']';
				break;
			case 'checked':
				$out .= 'checked: true, values: [\''.esc_attr($value).'\']';
				break;
			default:
				$out .= 'values: [\''.esc_attr($value).'\']';
				break;
		}

		return $out;
	}

	/**
	* Check prefix wct_ in string
	* @return true/false
	* @since 1.0
	*/

	private function wct_check_prefix_in_block_id($block_id){
		
		$prefix = 'wct_'; $status = false;
		
		if( substr( $block_id, 0, 4 ) == $prefix ){
			$status = true;
		}

		return $status;
	}

}

/**
* Run class
* 1.0
*/
new WCT_Depends_On();
?>