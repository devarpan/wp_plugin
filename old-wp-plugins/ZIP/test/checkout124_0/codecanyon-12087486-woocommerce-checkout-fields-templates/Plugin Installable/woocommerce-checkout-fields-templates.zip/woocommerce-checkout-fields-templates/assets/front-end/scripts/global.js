(function($) {
	"use strict"; 
	var ajax_url = wct_ajax_url.ajax_url;
	
	$(document).ready(function() { 

		var checkout_form = $( 'form.checkout' );

		/*======remove file upload=========*/
		$('.progress-results .wct-file-remove').click(function(e) {
			
			$(this).closest('.uk-placeholder').find('.progress-results').hide();
			$(this).closest('.uk-placeholder').find('.progress-results p strong').text('');
			$(this).closest('.uk-placeholder').find('input[type="file"]').val('')
			e.preventDefault();

			return false;
		});

		/*=====remove account when already login==========*/
		if ($(".ossvn-account .user-logged-in").length){

			var text = $(".ossvn-account .ossvn-title").text();
			$(".ossvn-account .ossvn-title").html(''+ text +' <i class="fa fa-check"></i>');
		}
		
		$("#ossvn-wrapper #wct-woo-template .woocommerce-billing-fields .form-row label").each(function(){
			var current = $(this).next('.input-text');
			if (current.attr("placeholder")){
				$(this).hide();
			}
		});

		/*===special country checkout========*/
		if( $('#billing_country_field select').length == 0 ){
			$('#billing_country_field label').removeClass('ossvn-placeholder');
			$('#shipping_country_field label').removeClass('ossvn-placeholder');
		}

		if( $('#billing_state').hasClass('state_select ') ){
			$('#billing_state_field label').hide();
		}
		
	});
	
	$(window).bind("load",function(){
		$("#ossvn-wrapper .input-text").each(function(){
			if ($(this).attr("placeholder")){
				if ($(this).prev(".ossvn-placeholder").length){
					$(this).attr("placeholder","");
				}
			}
		});
	});


	function goToByScroll(id){
          // Reove "link" from the ID
        id = id.replace("link", "");
          // Scroll
        $('html,body').animate({
            scrollTop: $("#"+id).offset().top},
            'slow');
    }

	$('#r2').click(function(e) {
        e.preventDefault();
        $('#r1').removeAttr('checked');
        $('#r2').prop("checked", true);;
        $('#ossvn-billing').addClass('uk-active');
        goToByScroll('ossvn-billing');
    });

    $('body').on('click',function(event){
		if ($(".ossvn-datepicker-wrap.active").length){
			var current = $(event.target);
			if (!(current.parents(".ossvn-datepicker-wrap").length || current.hasClass("ossvn-datepicker-wrap") || current.next().hasClass("active"))){
				$(".ossvn-datepicker-wrap").removeClass("active");
			}
		}
	});
	
	//
	window.wct_get_data_upload = function (selector) {
        
        var data = [];

        $(''+ selector +' .uk-alert li img').each(function(){
        	
        	var img_url = $(this).attr('src'),
        	img_name = $(this).data('name'),
        	img_id = $(this).data('id');
        	data.push({
				'name' : img_name,
				'url' : img_url,
				'id': img_id
			});

        });
        if( data != '' ){

        	$(''+ selector +' .uk-alert input[type="hidden"]').val( JSON.stringify(data) );
        }else{
        	$(''+ selector +' .uk-alert').hide();
        	$(''+ selector +' .uk-alert input[type="hidden"]').val('');
        }
    };

    window.wct_remove_data_upload = function (selector) {
        
        var data = [];

        $(''+ selector +' .success .remove_img').click(function(e) {

        	var ajax_url = wc_checkout_params.ajax_url,
        	$this = $(this),
			attach_id = $(this).data('delete'),
			r = confirm("Press OK to delete this file, Cancel to leave!");

			if (r == true) {

				$.ajax({
					type: 'POST',
					url: ajax_url,
					data: {
						action: 'wct_delete_upload',
						attach_id: attach_id
					},
					success: function(respon)
					{
						$this.parent('.success').remove();
        				wct_get_data_upload(selector);
					}
				});
			}
        	return false;
        });

    };

    window.disable_specific_dates = function ( date ) {

    	var m = date.getMonth();
		var d = date.getDate();
		var y = date.getFullYear();

		var currentdate = (m + 1) + '-' + d + '-' + y ;
		for (var i = 0; i < specific_dates.length; i++) {
			if ($.inArray(currentdate, specific_dates) != -1 ) {
				return [false];
			}
		}

    };

    /**
    * Price fields
    *
    * @author Comfythemes
    * @since 1.0
    */
    var wct_price_field = {
		
		ajax_url: wct_ajax_url.ajax_url,
		$checkout_form: $( 'form.checkout' ),
		init: function() {

			this.$checkout_form.on( 'blur input change', '.form-row[data-price="on"] .input-text, .form-row[data-price="on"] select, .form-row[data-price="on"] input[type="radio"]', this.wct_update_price_fields );
			this.$checkout_form.on( 'change', '.form-row[data-price="on"] input[type="checkbox"]', this.wct_checkbox_update_price_fields );

		},
		wct_update_price_fields: function() {
			
			var id = $(this),
			type = id.attr('type'),
			val = id.val();

			if( val == null || val == '-1' || val == '' ){
				wct_price_field.wct_delete_price_field(id);
			}else{
				wct_price_field.wct_add_price_field(id);
			}

		},
		wct_checkbox_update_price_fields: function() {

			var id = $(this),
			val = id.val(),
			parent = id.closest('.form-row').attr('id');

			var $val = $('#'+ parent + ' .ossvn-block-check-box:checked').map(function() {
			    return this.value;
			}).get().join(', ');

			if( $val == '' ){
				wct_price_field.wct_delete_price_field(id);
			}else{
				wct_price_field.wct_add_price_field(id);
			}

		},
		wct_add_price_field: function(id) {
			
			var parent = id.closest('.form-row').attr('id'),
			block_id = id.attr('name'),
			price = $('#'+ parent).attr('data-price'),
			price_value = $('#'+ parent).attr('data-price-value'),
			price_title = $('#'+ parent +' label').first().text(),
			input_value = id.val();

			if( $('#'+ parent).hasClass('form-row-dropdown') ){
				var input_type = 'select';
			}else{
				var input_type = id.attr('type');
			}

			if ( typeof price !== 'undefined' && price != '' ) {

		        $.ajax({
		            type: 'POST',
		            url: ajax_url,
		            data: {
		                action: 'wct_custom_price',
		                price_value: price_value,
		                price_title: price_title,
		                input_value: input_value,
		                input_type: input_type,
		                block_id: block_id
		            },
		            success: function(respon)
		            {
		                var data = $.parseJSON(respon);
		                if(data.status == 1){
		                	$( 'body' ).trigger( 'update_checkout' );
		                }
		            }
		        }); 	
			}

		},
		wct_delete_price_field: function(id) {
			
			var parent = id.closest('.form-row').attr('id'),
			block_id = id.attr('name'),
			price = $('#'+ parent).attr('data-price'),
			price_value = $('#'+ parent).attr('data-price-value'),
			price_title = $('#'+ parent +' label').first().text(),
			input_value = id.val();

			if( $('#'+ parent).hasClass('form-row-dropdown') ){
				var input_type = 'select';
			}else{
				var input_type = id.attr('type');
			}

			if ( typeof price !== 'undefined' && price == 'on' ) {

		        $.ajax({
		            type: 'POST',
		            url: ajax_url,
		            data: {
		                action: 'wct_del_price',
		                price_value: price_value,
		                price_title: price_title,
		                input_value: input_value,
		                input_type: input_type,
		                block_id: block_id
		            },
		            success: function(respon)
		            {
		                var data = $.parseJSON(respon);console.log(data.html);
		                if(data.status == 1){
		                	$('.woocommerce-checkout-review-order-table .fee').hide();
		                	$( 'body' ).trigger( 'update_checkout' );
		                }
		            }
		        }); 	
			}

		}

	};

	wct_price_field.init();
	
})(jQuery);