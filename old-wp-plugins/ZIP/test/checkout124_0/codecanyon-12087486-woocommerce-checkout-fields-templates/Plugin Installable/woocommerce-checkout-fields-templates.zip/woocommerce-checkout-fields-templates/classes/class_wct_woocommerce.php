<?php 
/**
 * Functions for woocommerce.
 *
 * @link       http://demo.comfythemes.com/wct/
 * @since      1.0
 *
 * @package    woocommerce-checkout-templates
 * @subpackage woocommerce-checkout-templates/classes
 * @author     OSVN <contact@outsourcevietnam.co>
 * @coder Nam
 */
defined( 'ABSPATH' ) OR exit;

/**
* 
*/
class WCT_Woocommerce
{
	/**
	* Construct
	* @since 1.0
	*/
	function __construct()
	{
		add_action( 'wp_ajax_wct_login', array($this, 'wct_login') );
        add_action( 'wp_ajax_nopriv_wct_login', array($this, 'wct_login') );

        add_action( 'wp_ajax_valid_post_code', array($this, 'wct_valid_post_code') );
        add_action( 'wp_ajax_nopriv_valid_post_code', array($this, 'wct_valid_post_code') );

        //
        add_filter( 'woocommerce_checkout_fields' , array($this, 'wct_override_checkout_fields') );
        add_filter( 'woocommerce_billing_fields', array($this, 'wct_override_required_fields'), 10, 1 );
        add_filter( 'woocommerce_shipping_fields', array($this, 'wct_shipping_required_fields'), 10, 1 );

        //
        add_action( 'init', array($this, 'wct_remove_coupon_form') );
        add_action( 'init', array($this, 'wct_clear_cart_url') );

        add_action( 'wp_footer', array( $this, 'wct_allowed_countries_field' ), 100 );

        add_action('woocommerce_checkout_update_order_meta', array($this, 'wct_save_steps_for_order_success'));

	}

	/**
	* Remove default coupon vs login form
	* @since    1.0
	*/
	public function wct_remove_coupon_form(){
		remove_action( 'woocommerce_before_checkout_form', 'woocommerce_checkout_login_form', 10 );
		remove_action( 'woocommerce_before_checkout_form', 'woocommerce_checkout_coupon_form', 10 );
	}

	/**
	* Empty cart
	* @since 1.0
	*/
	public function wct_clear_cart_url() {
		global $woocommerce;
		if ( isset( $_GET['empty-cart'] ) ) {
			$woocommerce->cart->empty_cart(); 
		}
	}

	
	/**
	* AJAX Login
	* @since 1.0
	*/
	public function wct_login( $user_login = null, $password = null ){
		
		$status = array('status'=> '', 'logged_in' => false);
		
		if ( ! empty( $_POST['login'] ) && ! empty( $_POST['_wpnonce'] ) && wp_verify_nonce( $_POST['_wpnonce'], 'wct-login' ) ) {

			$username = empty( $_POST['username'] ) ? $user_login : sanitize_text_field( $_POST['username'] );
        	$password = empty( $_POST['password'] ) ? $password : sanitize_text_field( $_POST['password'] );
        	$remember = empty( $_POST['password'] ) ? $password : sanitize_text_field( $_POST['password'] );   

        	if ( validate_username( $username ) ){

            	if ( username_exists( $username ) ){

            		$creds = array();

					$creds['user_login'] = $username;
					$creds['user_password'] = $password;
					$creds['remember'] = false;
					
					$user = wp_signon( $creds, false );
                    if( is_wp_error( $user ) ){
                    	
                    	$status['status'] = $user->get_error_code();
                    }else{
                    	$status['logged_in'] = true;
                    	$status['status'] = __('Login success. You are now logged in as <strong>'.$user->display_name.'</strong>', 'wct');
                    }

            	}else{

            		$status['status'] = __('Username does not exists', 'wct');
            	}
            }else{

            	$status['status'] = __('Invalid username', 'wct');
            }


		}else{
			$status['status'] = __( 'Security check.', 'wct ' );
		}

		echo json_encode( $status );
		die();
	}

	/**
	* Billing field manager
	* Check if field exists. If not, remove field
	* @since 1.0
	*/
	public function wct_override_checkout_fields($fields){
		
		if( $wct_all_fields = get_option('wct_all_field') ){

			/**
			* Billing fields
			*/
			if ( !in_array_r( 'billing_country', $wct_all_fields ) ) { 
			    unset($fields['billing']['billing_country']);
			}
			
			if ( !in_array_r( 'billing_first_name', $wct_all_fields ) ) { 
			    unset($fields['billing']['billing_first_name']);
			}
			
			if ( !in_array_r( 'billing_last_name', $wct_all_fields ) ) { 
			    unset($fields['billing']['billing_last_name']);
			}
			
			if ( !in_array_r( 'billing_company', $wct_all_fields ) ) { 
			    unset($fields['billing']['billing_company']);
			}
			
			if ( !in_array_r( 'billing_address_1', $wct_all_fields ) ) { 
			    unset($fields['billing']['billing_address_1']);
			}
			
			
			if ( !in_array_r( 'billing_postcode', $wct_all_fields ) ) { 
			    unset($fields['billing']['billing_postcode']);
			}
			
			if ( !in_array_r( 'billing_city', $wct_all_fields ) ) { 
			    unset($fields['billing']['billing_city']);
			}

			if ( !in_array_r( 'billing_email', $wct_all_fields ) ) { 
			    unset($fields['billing']['billing_email']);
			}

			if ( !in_array_r( 'billing_phone', $wct_all_fields ) ) { 
			    unset($fields['billing']['billing_phone']);
			}
			
			
			/**
			* Shipping fields
			*/

			if ( !in_array_r( 'order_comments', $wct_all_fields ) ) { 
			    unset($fields['order']['order_comments']);
			}
			
			if ( !in_array_r( 'shipping_country', $wct_all_fields ) ) { 
				unset($fields['shipping']['shipping_country']);
			}

			if ( !in_array_r( 'shipping_first_name', $wct_all_fields ) ) { 
				unset($fields['shipping']['shipping_first_name']);
			}
			
			if ( !in_array_r( 'shipping_last_name', $wct_all_fields ) ) { 
				unset($fields['shipping']['shipping_last_name']);
			}
			
			
			if ( !in_array_r( 'shipping_company', $wct_all_fields ) ) { 
				unset($fields['shipping']['shipping_company']);
			}
			
			if ( !in_array_r( 'shipping_address_1', $wct_all_fields ) ) { 
			    unset($fields['shipping']['shipping_address_1']);
			}
			
			if ( !in_array_r( 'shipping_postcode', $wct_all_fields ) ) { 
			    unset($fields['shipping']['shipping_postcode']);
			}
			
			if ( !in_array_r( 'shipping_city', $wct_all_fields ) ) { 
			    unset($fields['shipping']['shipping_city']);
			}

		}

		return $fields;
	}

	/**
	* Allowed countries for the store
	*
	* @author comfythemes
	* @since 1.1
	*/
	public function wct_allowed_countries_field(){

		$allowed_countries 			= get_option( 'woocommerce_allowed_countries' );
		$specific_allowed_countries = get_option('woocommerce_specific_allowed_countries');

		$countries = array();

		if( $allowed_countries == 'specific' && !empty($specific_allowed_countries) ){

			if( count($specific_allowed_countries) == 1 ){

				?>
				<script>
				(function($) {
    				"use strict";

    				$('#billing_country').val('<?php echo current(array_values($specific_allowed_countries));?>');

    			})(jQuery);
				</script>
				<?php
			}
		}

	}

	/**
	* Check billing required fields
	* @since 1.0
	*/
	public function wct_override_required_fields( $billing_fields ){

		if( $wct_all_fields = get_option('wct_all_field') ){

			foreach ( $wct_all_fields as $wct_field ) {

				if($wct_field['block_type'] == 'woo_field'){

					if ( !in_array_r( 'billing_last_name', $wct_all_fields ) || $wct_field['block_required'] != 'on' ) {
					    $billing_fields['billing_last_name']['required'] = false;
					}
					
					if ( !in_array_r( 'billing_first_name', $wct_all_fields ) || $wct_field['block_required'] != 'on' ) {
					    $billing_fields['billing_first_name']['required'] = false;
					}
					
					if ( !in_array_r( 'billing_country', $wct_all_fields ) || $wct_field['block_required'] != 'on' ) {
						$billing_fields['billing_country']['required'] = false;
					}
					
					if ( !in_array_r( 'billing_phone', $wct_all_fields ) || $wct_field['block_required'] != 'on' ) {
						$billing_fields['billing_phone']['required'] = false;
					}

					if ( !in_array_r( 'billing_state', $wct_all_fields ) || $wct_field['block_required'] != 'on' ) {
						$billing_fields['billing_state']['required'] = false;
					}

					if ( !in_array_r( 'billing_address_1', $wct_all_fields ) || $wct_field['block_required'] != 'on' ) {
					    $billing_fields['billing_address_1']['required'] = false;
					}
					
					if ( !in_array_r( 'billing_city', $wct_all_fields ) || $wct_field['block_required'] != 'on' ) {
						$billing_fields['billing_city']['required'] = false;
					}

					if ( !in_array_r( 'billing_postcode', $wct_all_fields ) || $wct_field['block_required'] != 'on' ) {
						$billing_fields['billing_postcode']['required'] = false;
					}
					
				}

			}
		}

		return $billing_fields;
	}

	/**
	* Check shipping required fields
	* @since 1.0
	*/
	public function wct_shipping_required_fields( $shipping_fields ){

		if( $wct_all_fields = get_option('wct_all_field') ){

			foreach ( $wct_all_fields as $wct_field ) {

				if($wct_field['block_type'] == 'woo_field'){

					if ( !in_array_r( 'shipping_first_name', $wct_all_fields ) || $wct_field['block_required'] != 'on' ) {
					    $shipping_fields['shipping_first_name']['required'] = false;
					}
					
					if ( !in_array_r( 'shipping_last_name', $wct_all_fields ) || $wct_field['block_required'] != 'on' ) {
					    $shipping_fields['shipping_last_name']['required'] = false;
					}
					
				}

			}
		}

		return $shipping_fields;
	}

	/**
	* Valid post code
	*
	* @author Comfythemes
	* @since 1.2
	*/
	public function wct_valid_post_code(){
		
		$status = array('status'=> '0');

		if( isset($_POST['country']) && !empty($_POST['country']) && isset($_POST['postCode']) && !empty($_POST['postCode']) ){

			if( WC_Validation::is_postcode( $_POST['postCode'], $_POST['country'] ) ){
				$status['status'] = 1;
			}
		}

		echo json_encode($status);
		die();
	}

	/**
	* Function save html step for template 2 - Step - modern
	*
	* @author Comfythemes
	* @since 1.3
	*/
	public function wct_save_steps_for_order_success( $order_id ){

		if ( ! empty( $_POST['wct_save_steps_row_2'] ) ) {
	        update_option( 'wct_save_steps_row_2', $_POST['wct_save_steps_row_2'] );
	    }
	}


}

/**
* Run class
* @since 1.0
*/
new WCT_Woocommerce();
?>