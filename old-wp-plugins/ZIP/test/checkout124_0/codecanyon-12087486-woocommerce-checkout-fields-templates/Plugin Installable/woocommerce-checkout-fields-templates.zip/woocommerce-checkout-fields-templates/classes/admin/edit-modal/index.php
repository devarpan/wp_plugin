<?php // Silence is golden
defined( 'ABSPATH' ) OR exit;