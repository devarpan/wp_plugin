<?php if(is_active_sidebar('wct-sidebar-bottom')){?>
	<div id="ossvn-sidebar-bottom">
	<?php dynamic_sidebar('wct-sidebar-bottom');?>
	</div>
<?php }?>