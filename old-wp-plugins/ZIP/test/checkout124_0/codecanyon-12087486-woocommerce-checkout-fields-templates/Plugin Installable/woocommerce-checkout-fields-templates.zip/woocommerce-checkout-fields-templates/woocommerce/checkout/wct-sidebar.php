<?php if(is_active_sidebar('wct-sidebar')){?>
	<?php dynamic_sidebar('wct-sidebar');?>
<?php }?>