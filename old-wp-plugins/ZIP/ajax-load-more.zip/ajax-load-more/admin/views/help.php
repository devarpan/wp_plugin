<div class="admin ajax-load-more" id="alm-help">
	<div class="wrap">
		<div class="header-wrap">
   			<h1>
      			<?php echo ALM_TITLE; ?>: <strong><?php _e('Help', 'ajax-load-more'); ?></strong>
               <em><?php _e('Get started with our four step guide to painless implementation!', 'ajax-load-more'); ?></em>
   			</h1>
		</div>
		<div class="cnkt-main forceColors">
		   <div class="group">

				<img src="<?php echo ALM_ADMIN_URL; ?>img/infographic.png">

		   </div>
	   </div>
	   <div class="cnkt-sidebar">
	   	<?php include_once( ALM_PATH . 'admin/includes/cta/resources.php');	?>
	   	<?php include_once( ALM_PATH . 'admin/includes/cta/dyk.php');	?>
	   </div>

	</div>
</div>
