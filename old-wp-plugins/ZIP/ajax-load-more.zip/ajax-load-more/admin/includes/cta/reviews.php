<h4><?php _e('Leave a Review', 'ajax-load-more'); ?> <i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i></h4>
<p><?php _e('Good <em>or</em> bad - all reviews will help Ajax Load More push forward and grow.', 'ajax-load-more'); ?> </p>
<ul class="share">
   <li><a href="https://wordpress.org/support/view/plugin-reviews/ajax-load-more" target="_blank"><?php _e('Write Review', 'ajax-load-more'); ?></a></li>   
</ul>
