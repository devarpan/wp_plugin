<div class="cta padding-bottom">
	<h3>Add-ons</h3>
	<div class="cta-inner">
	   <p style="padding-bottom: 10px;">Ajax Load More offers a variety of unique <a href="admin.php?page=ajax-load-more-add-ons">add-ons</a> that will extend and enhance the core functionality of the plugin.</p>
	   <p>Add-ons can be purchased individually or in a <a href="https://connekthq.com/plugins/ajax-load-more/add-ons/bundle/?utm_source=WP%20Admin&utm_medium=ALM%20Dashboard&utm_campaign=Bundle" target="_blank">bundle</a> which gives you access all of the Ajax Load More add-ons at over 50% off the regular price!</p>
	</div>
	<a href="admin.php?page=ajax-load-more-add-ons" class="visit" target="_blank"><i class="fa fa-chevron-circle-right"></i> View Add-ons</a>
</div>			