<?php
// Direct access security
if (!defined('TM_EPO_PLUGIN_SECURITY')){
	die();
}
?>
<li id="<?php echo $field_id;?>" class="tm-extra-product-options-field nopadding">