<?php
// Direct access security
if (!defined('TM_EPO_PLUGIN_SECURITY')){
	die();
}
?>
<li class="tmcp-field-wrap"><?php echo $divider;?></li>