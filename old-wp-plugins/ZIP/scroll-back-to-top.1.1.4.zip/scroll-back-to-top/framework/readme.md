v1.0 - Initial bootstrap class created, initial controller created.
v1.1 - Updates to bootstrap, implement autoloading.  Minor controller updates.
v1.2 - Adds plugin name and text domain to bootstrap and controller.  Minor controller updates.  Adds basic plugin user options framework.  Changes to parameters passed to bootstrap and controller, update all existing plugins.
v1.3 - Adds contextual help support to the admin menu controller.  Adds ability to init options in user options collection if options don't currently exist.
