<?php
//Polish Language
//Facebook
$wpl_fblang='en_US'; //http://cultureslurp.com/how-to-add-facebook-like-button-like-box-for-different-languages/ see this page for language codes
//Twitter
$wpl_onTwitter='na Twitterze';
$wpl_Follow='śledzić';
$wpl_LatestTweet='Najnowsze Tweet';
$wpl_peoplefollow='ludzie podążają';
$wpl_follows='podąża';
$wpl_people='ludzie';
$wpl_Tweetto='tweetnąć do';
$wpl_twlang='pl';   //https://dev.twitter.com/web/overview/languages.html
//Google Plus
$wpl_gpluslang='pl'; //https://developers.google.com/+/web/+1button/?hl=en#available-languages see this page for language codes
//Youtube
//No language options available
//Subscription
$wpl_enteremailhere='Wpisz swój adres emailowy tutaj...';
$wpl_Submit='Zatwierdź';
$wpl_SubscribetoReceive='Zapisz się, aby otrzymywać na maila';
//Pinterest
//No language options available
//LinkedIn
//LinkedIn will show up in whatever language your profile or LinkedIn page is set to in your LinkedIn settings
//Contact Us
$wpl_Name='Nazwa';
$wpl_Email='E-mail';
$wpl_EnterYourMessage='Wpisz tutaj swoją wiadomość...';
$wpl_EnterNumberFrom='Wpisz numer z góry';
$wpl_Contact_Us='Skontaktuj się z nami';
$wpl_Contact_Me='Skontaktuj się ze mną';
//Flickr
//No language options available
//DeviantART
//No language options available
//Instagram
$wpl_Photos='Zdjęcia';
$wpl_Followers='ludzie';
$wpl_Following='Następujący';
$wpl_invaliderror='Nieprawidłowa nazwa użytkownika, żadnych zdjęć, lub serwery Instagram nie został znaleziony';
//Vimeo
$wpl_onVimeo='on Vimeo';
$wpl_Videos='filmy';
$wpl_vimeoerror='Błąd: Nieprawidłowa nazwa użytkownika lub serwer vimeo nie może zostać osiągnięty.';