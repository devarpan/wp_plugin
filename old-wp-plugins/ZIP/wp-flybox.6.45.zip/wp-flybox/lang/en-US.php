<?php
//English Language (default)
//Facebook
$wpl_fblang='en_US'; //http://cultureslurp.com/how-to-add-facebook-like-button-like-box-for-different-languages/ see this page for language codes
//Twitter
$wpl_onTwitter='on Twitter';
$wpl_Follow='Follow';
$wpl_LatestTweet='Latest Tweet';
$wpl_peoplefollow='people follow';
$wpl_follows='follows';
$wpl_people='people';
$wpl_Tweetto='Tweet to';
$wpl_twlang='en';   //https://dev.twitter.com/web/overview/languages.html
//Google Plus
$wpl_gpluslang='en-US'; //https://developers.google.com/+/web/+1button/?hl=en#available-languages see this page for language codes
//Youtube
//No language options available
//Subscription
$wpl_enteremailhere='Enter Your E-Mail Here...';
$wpl_Submit='Submit';
$wpl_SubscribetoReceive='Subscribe to Receive E-Mail Updates';
//Pinterest
//No language options available
//LinkedIn
//LinkedIn will show up in whatever language your profile or LinkedIn page is set to in your LinkedIn settings
//Contact Us
$wpl_Name='Name';
$wpl_Email='Email';
$wpl_EnterYourMessage='Enter Your Message Here...';
$wpl_EnterNumberFrom='Enter number from above';
$wpl_Contact_Us='Contact Us';
$wpl_Contact_Me='Contact Me';
//Flickr
//No language options available
//DeviantART
//No language options available
//Instagram
$wpl_Photos='Photos';
$wpl_Followers='Followers';
$wpl_Following='Following';
$wpl_invaliderror='Invalid username, no pictures, or instagram servers not found';
//Vimeo
$wpl_onVimeo='on Vimeo';
$wpl_Videos='Videos';
$wpl_vimeoerror='Error: Invalid username or vimeo server cannot be reached.';