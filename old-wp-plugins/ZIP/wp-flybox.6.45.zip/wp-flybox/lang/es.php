<?php
//English Language (default)
//Facebook
$wpl_fblang='es_LA'; //http://cultureslurp.com/how-to-add-facebook-like-button-like-box-for-different-languages/ see this page for language codes
//Twitter
$wpl_onTwitter='en Twitter';
$wpl_Follow='Seguir';
$wpl_LatestTweet='Tweet MÃ¡s Reciente';
$wpl_peoplefollow='la gente sigue';
$wpl_follows='siguiente';
$wpl_people='personas';
$wpl_Tweetto='Tweet en';
$wpl_twlang='es'; //https://dev.twitter.com/web/overview/languages.html
//Google Plus
$wpl_gpluslang='es'; //https://developers.google.com/+/web/+1button/?hl=en#available-languages see this page for language codes
//Youtube
//No language options available
//Subscription
$wpl_enteremailhere='introduzca su email aquÃ­...';
$wpl_Submit='Entregar';
$wpl_SubscribetoReceive='SuscrÃ­bete para recibir informaciÃ³n';
//Pinterest
//No language options available
//LinkedIn
//LinkedIn will show up in whatever language your profile or LinkedIn page is set to in your LinkedIn settings
//Contact Us
$wpl_Name='nombre';
$wpl_Email='Email';
$wpl_EnterYourMessage='Ingrese su mensaje aquÃ­...';
$wpl_EnterNumberFrom='Ingrese el nÃºmero desde arriba';
$wpl_Contact_Us='ContÃ¡ctenos';
$wpl_Contact_Me='ContÃ¡ctame';
//Flickr
//No language options available
//DeviantART
//No language options available
//Instagram
$wpl_Photos='Fotos';
$wpl_Followers='Seguidores';
$wpl_Following='Siguiendo';
$wpl_invaliderror='Nombre de usuario no vÃ¡lido, no hay fotos o servidores instagram no encontrado';
//Vimeo
$wpl_onVimeo='en Vimeo';
$wpl_Videos='VÃ­deos';
$wpl_vimeoerror='Error: nombre de usuario no vÃ¡lido o servidor vimeo no se puede llegar.';