<?php
namespace Aelia\WC\CurrencySwitcher\AffiliateWP;
if(!defined('ABSPATH')) exit; // Exit if accessed directly

class Aelia_CS_AffiliateWP_Install extends \Aelia\WC\Aelia_Install {
	// Dummy Installer class
}
