/* JavaScript for Frontend pages */
jQuery(document).ready(function($) {
	// Here jQuery can be accessed using the "$" variable
});

