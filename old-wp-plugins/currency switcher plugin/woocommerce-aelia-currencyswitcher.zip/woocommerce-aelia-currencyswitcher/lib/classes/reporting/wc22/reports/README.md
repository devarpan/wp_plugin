## Changes in WooCommerce 2.2 reports
Most reports in WC2.2 don't need to be overridden. WC2.2 and later finally implement filters that allow to change the report data without having to duplicate entire classes, as it happened in WC2.1 and earlier.
